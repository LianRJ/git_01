// JavaScript Document
//购物车
var DL2 = document.getElementById("dl2");
var GWC1 = document.getElementById("gwc1");
var GWC2 = document.getElementById("gwc2");
var DL4 = document.getElementById("dl4");
var time = null;
DL2.onmouseover = DL4.onmouseover = function () {
	clearTimeout(time);
	DL2.style.color = "#FF7200";
	GWC1.style.display = "none";
	GWC2.style.display = "inline";
	DL4.style.display = "inline"
}
DL2.onmouseout = DL4.onmouseout = function () {
		time = setTimeout(function () {
			DL2.style.color = "#B0B0B0";
			GWC1.style.display = "inline";
			GWC2.style.display = "none";
			DL4.style.display = "none";
		}, 100)
	}
	//搜索框
var SSK = document.getElementById("ssk");
var SSKT = document.getElementById("sskt");
var SSCD = document.getElementById("sscd");
SSKT.onmouseover = function () {
	SSKT.src = "img/11001.png";
	SSKT.style.border = "1px solid #FF7200";
}
SSKT.onmouseout = function () {
	SSKT.src = "img/1100.png";
	SSKT.style.border = "1px solid #E9E9E9";
}
SSK.onfocus = function () {
	SSK.style.border = "1px solid #FF7200";
	SSKT.style.border = "1px solid #FF7200";
	SSCD.style.display = "inline";
}
SSK.onblur = function () {
		SSK.style.border = "1px solid #E9E9E9";
		SSKT.style.border = "1px solid #E9E9E9";
		SSCD.style.display = "none";
	}
	//上导航
var MIXXK = document.getElementById("mixxk");
var MIXXK2 = document.getElementById("mixxk2");
var MIXXK3 = document.getElementById("mixxk3");
var SDH = document.getElementsByClassName("sdh");
SDH[0].onmousemove = MIXXK.onmouseover = function () {
	clearTimeout(time);
	MIXXK.style.display = "inline";
}
SDH[0].onmouseout = MIXXK.onmouseout = function () {
	time = setTimeout(function () {
		MIXXK.style.display = "none";
	}, 100)
}
for (var i = 1; i < SDH.length; i++) {
	SDH[i].onmouseover = function () {
		clearTimeout(time);
		MIXXK.style.display = "inline";
		MIXXK3.style.display = "none";
	}
	SDH[i].onmouseout = MIXXK.onmouseout = function () {
		time = setTimeout(function () {
			MIXXK.style.display = "none";
			MIXXK3.style.display = "inline";
		}, 100)
	}
}
//左导航
var YCDHL = document.getElementById("ycdhl");
var YCDHL2 = document.getElementById("ycdhl2");
var YCDHL3 = document.getElementById("ycdhl3");
var DHLI = document.getElementsByClassName("dhli");
DHLI[0].onmouseover = YCDHL.onmouseover = function () {
	clearTimeout(time);
	YCDHL.style.display = "inline";
}
DHLI[0].onmouseout = YCDHL.onmouseout = function () {
	time = setTimeout(function () {
		YCDHL.style.display = "none";
	}, 50)
}

for (var i = 1; i < DHLI.length; i++) {
	DHLI[i].onmouseover = function () {
		clearTimeout(time);
		YCDHL.style.display = "inline";
		YCDHL3.style.display = "none";
	}
	DHLI[i].onmouseout = YCDHL.onmouseout = function () {
		time = setTimeout(function () {
			YCDHL.style.display = "none";
			YCDHL3.style.display = "inline";
		}, 50)
	}
}
//大图
var LBTDT = document.getElementById("lbtdt");
var TP = document.getElementsByClassName("tp");
TP[0].onmouseover = function () {
	LBTDT.src = "img/banner5.jpg";
}
TP[1].onmouseover = function () {
	LBTDT.src = "img/banner4.jpg";
}
TP[2].onmouseover = function () {
	LBTDT.src = "img/banner3.jpg";
}
TP[3].onmouseover = function () {
	LBTDT.src = "img/banner2.jpg";
}
TP[4].onmouseover = function () {
		LBTDT.src = "img/banner1.jpg";
	}
//闪购时间
//var tc = (function() { 
//var int; 
//var total = 36000; 
//return function(elemID) { 
//obj = document.getElementsByClassName(elemID); 
//var s = (total%60) < 10 ? ('0' + total%60) : total%60; 
//var h = total/3600 < 10 ? ('0' + parseInt(total/3600)) : parseInt(total/3600); 
//var m = (total-h*3600)/60 < 10 ? ('0' + parseInt((total-h*3600)/60)) : parseInt((total-h*3600)/60); 
//obj[0].innerHTML = h; 
//obj[1].innerHTML = m; 
//obj[2].innerHTML = s; 
//total--; 
//int = setTimeout("tc('" + elemID + "')", 1000); 
//if(total < 0) clearTimeout(int); 
//} 
//})()
function DJS(){
	var D = new Date();
	var TC = document.getElementsByClassName("tc");
	var SJ = new Date("2018/9/5 10:00:00");
	var ms = SJ.getTime()- D.getTime();
	var s = ms/1000;
	var day = (s/(60*60*24)) < 10 ?('0'+parseInt(s/(60*60*24))) : parseInt(s/(60*60*24));
	var h = (s/(60*60)%24) < 10 ? ('0'+parseInt(s/(60*60)%24)) : parseInt(s/(60*60)%24);
	var m = (s/60%60) < 10 ? ('0'+parseInt(s/60%60)) : parseInt(s/60%60);
	var s = (s%60) < 10 ? ('0'+parseInt(s%60)) : parseInt(s%60);
	TC[0].innerHTML = h;
	TC[1].innerHTML = m;
	TC[2].innerHTML = s;
}
setInterval(DJS,1000)
	//右边栏
var R2 = document.getElementsByClassName("r2");
var R3 = document.getElementsByClassName("r3");
R2[0].onmouseover = function () {
	R3[0].src = "img/个人中心2.png";
}
R2[0].onmouseout = function () {
	R3[0].src = "img/个人中心1.png";
}
R2[1].onmouseover = function () {
	R3[1].src = "img/联系客服2.png";
}
R2[1].onmouseout = function () {
	R3[1].src = "img/联系客服1.png";
}
R2[2].onmouseover = function () {
	R3[2].src = "img/购物车2.png";
}
R2[2].onmouseout = function () {
	R3[2].src = "img/购物车1.png";
}
