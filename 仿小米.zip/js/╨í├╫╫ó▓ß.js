// JavaScript Document
var SJHM = document.getElementById("sjhm");
var SPAN = document.getElementById("span");
var Z = document.getElementById("z");
Z.onclick = function () {
	var sj = /^1[34578]\d{9}$/;
	if (SJHM.value.length == 0) {
		SPAN.style.display = "block";
		SPAN.innerHTML = "<img src='img/感叹号.png' id='gth'>请输入手机号码";
		SPAN.style.color = "#FF7200";
		return false;
	}
	if (sj.test(SJHM.value)) {
		window.location.href = "小米账号-登录.html";
		return true;
	} else {
		SPAN.style.display = "block";
		SPAN.innerHTML = "<img src='img/感叹号.png' id='gth'>手机号码格式错误";
		SPAN.style.color = "#FF7200";
		return false;
	}
}
