// JavaScript Document
var ZHDL = document.getElementById("zhdl");
var SMZC = document.getElementById("smzc");
var MMDL = document.getElementById("mmdl");
var SYS = document.getElementById("sys");
var QITA = document.getElementById("qita");
ZHDL.onclick = function () {
	ZHDL.style.color = "#FF7200";
	MMDL.style.display = "block";
	QITA.style.display = "block";
	SMZC.style.color = "#000000";
	SYS.style.display = "none";

}
SMZC.onclick = function () {
	SMZC.style.color = "#FF7200";
	SYS.style.display = "block";
	MMDL.style.display = "none";
	QITA.style.display = "none";
	ZHDL.style.color = "#000000";
}
var QQ = document.getElementById("qq");
var XINGL = document.getElementById("xinl");
var ZHIF = document.getElementById("zhif");
var WEIX = document.getElementById("weix");
QQ.onmouseover = function () {
	QQ.src = "img/qq (1).png";
}
QQ.onmouseout = function () {
	QQ.src = "img/qq.png";
}
XINGL.onmouseover = function () {
	XINGL.src = "img/xinlang (1).png";
}
XINGL.onmouseout = function () {
	XINGL.src = "img/xinlang.png";
}
ZHIF.onmouseover = function () {
	ZHIF.src = "img/支付宝 (1).png";
}
ZHIF.onmouseout = function () {
	ZHIF.src = "img/支付宝.png";
}
WEIX.onmouseover = function () {
	WEIX.src = "img/微信 (1).png";
}
WEIX.onmouseout = function () {
	WEIX.src = "img/微信.png";
}
var NAME = document.getElementById("name");
var PASS = document.getElementById("pass");
var SPAN = document.getElementById("span");
var DENGL = document.getElementById("dengl");
DENGL.onclick = function () {
	var yhm = /^\w{3,}$/;
	if (NAME.value.length == 0) {
		SPAN.style.display = "block";
		SPAN.innerHTML = "<img src='img/感叹号.png' id='gth'>请输入帐号";
		SPAN.style.color = "#FF7200";
		return false;
	}
	if (yhm.test(NAME.value)) {
		var mim = /^\w{4,8}$/;
		if (PASS.value.length == 0) {
			SPAN.innerHTML = "<img src='img/感叹号.png' id='gth'>请输入密码";
			SPAN.style.color = "#FF7200";
			return false;
		}
		if (mim.test(PASS.value)) {
			SPAN.style.display = "none";
			window.location.href = "小米商城.html";
			return true;
		} else {
			SPAN.innerHTML = "<img src='img/感叹号.png' id='gth'>用户名或密码不正确";
			SPAN.style.color = "#FF7200";
			return false;
		}
		return true;
	} else {
		SPAN.style.display = "block";
		SPAN.innerHTML = "<img src='img/感叹号.png' id='gth'>用户名不正确";
		SPAN.style.color = "#FF7200";
		return false;
	}
}
